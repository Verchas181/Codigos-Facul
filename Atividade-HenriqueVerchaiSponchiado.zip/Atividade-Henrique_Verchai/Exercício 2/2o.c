#include <stdio.h>
int a;
int main() {
    
    printf("Digite um número inteiro: ");
    scanf("%d", &a);

    for (int linha = 0; linha < a; linha++) {
        for (int coluna = 0; coluna < a; coluna++) {
            if (coluna == linha) {
                printf("x");
            } else {
                printf("+");
            }
        }
        printf("\n");
    }

    return 0;
}