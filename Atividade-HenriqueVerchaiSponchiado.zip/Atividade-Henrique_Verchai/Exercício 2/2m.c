#include <stdio.h>
int b;
int i =1;
int main() {
    
    printf("Digite um valor: ");
    scanf("%d", &b);
    while (i<b){
        if (b%i==0){
            printf("%d é divisível por %d",b,i);
        }
    }

    return 0;
}