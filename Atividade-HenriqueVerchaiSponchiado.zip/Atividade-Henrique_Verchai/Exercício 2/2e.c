#include <stdio.h>
int n;
float vol = 1;
int main(){
    printf("Escreva o numero de dimensoes e em seguida os seus valores");
    scanf("%d",&n);
    float vec[n];
    for(int i = 0;i<n;i++){
        scanf("%f",vec[i]);
        vol *= vec[i];
    }
    printf("%f",vol);
    return 0;
    

}