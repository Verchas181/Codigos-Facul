#include <stdio.h>
int i = 1;
int main() {
    while (i<=10000){
        printf("%d",i);
        i++;
    } 
    return 0;
}