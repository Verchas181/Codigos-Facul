#include <stdio.h>
int a;

int c;
int main(){
    printf("Escreva um número para desenhar um trinagulo retangulo");
    scanf("%d",a);
    int b = a*a;
    int d = a-1;
    while (b > 0){ 
        printf("%d",c);
        if(c == 1){
            printf("\n");
            c = d;
            d -=1;
        }
        b -= 1;
    }
    

    return 0;
}