#include <stdio.h>

int main() {
    int n = 20; 
    int a = 1, b = 1; 
    int c; 

    printf("Os primeiros %d números da sequência de Fibonacci são:\n", n);

   
    printf("%d %d ", a, b);

    
    for (int i = 3; i <= n; i++) {
        c = a + b;
        printf("%d ", c);
        a = b;
        b = c;
    }

    printf("\n");

    return 0;
}
