#include <stdio.h>

int main() {
    int base = 4;
    for (int i = 0; i < base; i++) {
        for (int j = 0; j <= i; j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
