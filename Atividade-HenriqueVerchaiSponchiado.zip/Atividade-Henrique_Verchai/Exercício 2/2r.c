
int main() {
    int C;

    
    printf("Digite um número inteiro C: ");
    scanf("%d", &C);

    int num = 2 * C - 1;

    for (int l = 0; l < num; l++) {
        for (int col = 0; col < num; col++) {
            if (col >= l && col < num - l) {
                printf("* ");
            } else {
                printf(". ");
            }
        }
        
        
        if (l == C - 1) {
            printf(": ");
            for (int col = 0; col < num; col++) {
                printf("* ");
            }
        }
        
       
        printf("\n");
    }

    return 0;
}




