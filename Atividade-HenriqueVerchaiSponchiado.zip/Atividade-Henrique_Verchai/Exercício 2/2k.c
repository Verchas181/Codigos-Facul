#include <stdio.h>

int main() {
    int N;
    printf("Digite um número N: ");
    scanf("%d", &N);
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            printf("%d ", i);
        }
        printf("\n");
    }

    return 0;
}
