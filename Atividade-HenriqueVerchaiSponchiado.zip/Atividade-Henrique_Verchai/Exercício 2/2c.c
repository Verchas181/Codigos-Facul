#include <stdio.h>
char frase[50];

int main (){
    printf("Escreva uma frase com até 40 caracteres:");
    fgets(frase,40,stdin);
    int x = strlen(frase);
    while(x > 40){
    fgets(frase,40,stdin);
    }
    return 0;

}