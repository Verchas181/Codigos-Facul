#include <stdio.h>

int main() {
    int N;

   
    printf("Digite a altura do Triângulo de Pascal: ");
    scanf("%d", &N);

   
    for (int linha = 0; linha < N; linha++) {
        int coeficiente = 1;

        
        for (int espaco = 0; espaco < N - linha; espaco++) {
            printf("   ");
        }

        
        for (int coluna = 0; coluna <= linha; coluna++) {
            printf("%6d", coeficiente);
            coeficiente = coeficiente * (linha - coluna) / (coluna + 1);
        }
        printf("\n");
    }
    return 0;
}
