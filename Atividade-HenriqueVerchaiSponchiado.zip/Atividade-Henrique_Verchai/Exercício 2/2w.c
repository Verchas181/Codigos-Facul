#include <stdio.h>
char b[32];  
int d = 0;  
int main() {
    

    printf("Digite um número binário: ");
    scanf("%s", &b);

    for (int i = 0; b[i] != '\0'; i++) {
        d = d * 2 + (b[i] - '0');
    }

    printf("O número binário %s é equivalente a %d em decimal.\n", b, d);

    return 0;
}
