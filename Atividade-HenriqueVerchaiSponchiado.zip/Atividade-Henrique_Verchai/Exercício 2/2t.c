#include <stdio.h>

int main() {
    int numero, proximoPrimo;
    int candidato;
    int ePrimo;

    printf("Digite um número primo: ");
    scanf("%d", &numero);

    
    candidato = numero + 1;

    while (1) {
        ePrimo = 1; 
        for (int i = 2; i <= candidato / 2; i++) {
            if (candidato % i == 0) {
                ePrimo = 0; // Se não é primo
                break;
            }
        }

        // Se for primo
        if (ePrimo) {
            proximoPrimo = candidato;
            break;
        }

        candidato++;
    }

 
    printf("O próximo número primo após %d é %d\n", numero, proximoPrimo);

    return 0;
}
