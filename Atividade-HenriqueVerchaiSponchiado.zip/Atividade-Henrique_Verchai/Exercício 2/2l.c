#include <stdio.h>

int main() {
    int a;
    printf("Digite um valor para a matriz: ");
    scanf("%d", &a);
    for (int i = 0; i < a; i++) {
        for (int j = 0; j < a; j++) {
            if (i == j) {
                printf("1 ");
            } else {
                printf("0 ");
            }
        }
    }
        printf("\n"); 

    return 0;
}
