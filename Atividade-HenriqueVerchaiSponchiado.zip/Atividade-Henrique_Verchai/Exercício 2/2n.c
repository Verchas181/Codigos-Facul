
#include <stdio.h>

int main() {
    int base, potencia;

    for (base = 1; base <= 9; base++) {
        printf("Potências de %d: ", base);

        for (potencia = 1; potencia <= 4; potencia++) {
            int resultado = 1;
            for (int i = 1; i <= potencia; i++) {
                resultado *= base;
            }

            printf("%d ", resultado);
        }

        printf("\n");
    }

    return 0;
}






