int main() {
    int altura = 4; 
    int Menor = 3; 
    int Maior = 6; 

    
    for (int i = 0; i < altura; i++) {
        for (int j = 0; j < Maior; j++) {
            if (i == 0) {
                printf("*");
            }
            else if (j < (Maior - Menor) / 2 - i || j >= (Maior - Menor) / 2 + Menor + i) {
                printf("");
            }
            else {
                printf("*");
            }
        }
        printf("\n");
    }
    return 0;
}