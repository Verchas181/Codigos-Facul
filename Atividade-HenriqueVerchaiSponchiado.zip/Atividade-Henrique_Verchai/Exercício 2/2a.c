#include <stdio.h>
char nome[50];

int main (){
    printf("Escreva um nome:");
    scanf("%s",&nome);
    printf("%c,%c,%c",nome[0],nome[strlen(nome)-1],nome[3]);
    for(int i = 0;i < 3;i++){
        printf("%c",nome[i]);
    }
    for (int j = strlen(nome)-1;j >= 0;j--){
        printf("%c",nome[j]);
    }
    for (int k = 0;k < strlen(nome);k++){
        printf("%c,%d",nome[k],k+1);
        return 0;

    }
}