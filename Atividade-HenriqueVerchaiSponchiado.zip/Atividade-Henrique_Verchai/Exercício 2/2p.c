#include <stdio.h>

int main() {
    int N;
    printf("Digite um número inteiro N: ");
    scanf("%d", &N);
    for (int linha = 0; linha < N; linha++) {
        for (int coluna = 0; coluna < N; coluna++) {
            if (coluna >= linha && coluna < N - linha) {
                printf("* ");
            } else {
                printf(". ");
            }
        }
        printf("\n");
    }

    return 0;
}
