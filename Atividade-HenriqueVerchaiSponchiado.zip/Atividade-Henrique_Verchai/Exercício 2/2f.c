#include <stdio.h>
int a =3;
int i=0;
int main(){
    while(i<a*a){
        printf("*");
        if(i%a==0){
            printf("\n");
        }
    }

    return 0;