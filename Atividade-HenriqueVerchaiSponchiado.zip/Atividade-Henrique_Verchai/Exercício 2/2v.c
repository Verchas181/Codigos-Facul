#include <stdio.h>
int a;

int main (){
    printf("Escreva um numero inteiro:");
    scanf("%d",&a);
    int i = a;
    while (i>0){
        for (int j = a;j>0;j--){
            printf("*");
        }
        i--;
    }
    
    if (i == 0){
        while (i<a){
        for (int j = 0;j<a;j++){
            printf("*");
        }
        i++;
    }
    }

    return 0;
}