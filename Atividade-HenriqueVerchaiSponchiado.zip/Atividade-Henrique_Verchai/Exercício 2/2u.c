#include <stdio.h>

int main() {
    int a;

    printf("Digite um número inteiro: ");
    scanf("%d", &a);

    for (int l = 1; l <= a; l++) {
        for (int c = 1; c <= a; c++) {
            if (c <= l) {
                printf("*");
            } else {
                printf("%d", l);
            }
        }
        printf("\n");
    }

    return 0;
}
