#include <stdio.h>
int vec[41];
int a;
int main(){
    printf("Adicione até 40 números");
    for (int i = 0;i<40;i++){
        scanf("%d",vec[i]);
    }
    printf("Digite outro numero");
    scanf("%d",a);
    for (int j = 0;j<40;j++){
        if(a == vec[j]){
            print("SIM");
            break;
        }
        if (j == 40){
            printf("NÃO");
            break;
        }
    }


    return 0;
}