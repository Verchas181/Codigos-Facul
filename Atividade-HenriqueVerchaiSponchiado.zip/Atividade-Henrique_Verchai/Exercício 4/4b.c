#include <stdio.h>
char vec[40];
int main(){
    printf("Digite um nome");
    scanf("%s",&vec);
    for (int i =0;i<40;i++){
        if(i%2 != 0){
        printf("%c",vec[i]);
        }
    }
    return 0;
}