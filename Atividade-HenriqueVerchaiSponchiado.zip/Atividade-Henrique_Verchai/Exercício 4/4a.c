#include <stdio.h>
char vec[40];
int main(){
    printf("Digite um nome");
    scanf("%s",&vec);
    for (int i =0;i<4;i++){
        printf("%c",vec[i]);
    }
    return 0;
}