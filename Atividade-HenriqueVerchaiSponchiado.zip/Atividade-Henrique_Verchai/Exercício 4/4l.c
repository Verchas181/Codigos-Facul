#include <stdio.h>


double mediaLinha(int matriz[][1000], int l, int c, int i) {
    double soma = 0.0;
    for (int j = 0; j < c; j++) {
        soma += matriz[i][j];
    }
    return soma / c;
}


double mediaColuna(int matriz[][1000], int l, int c, int i) {
    double soma = 0.0;
    for (int j = 0; j < l; j++) {
        soma += matriz[j][i];
    }
    return soma / l;
}


int somaDiagonalPrincipal(int matriz[][1000], int n) {
    int soma = 0;
    for (int i = 0; i < n; i++) {
        soma += matriz[i][i];
    }
    return soma;
}


int somaDiagonalSecundaria(int matriz[][1000], int n) {
    int soma = 0;
    for (int i = 0; i < n; i++) {
        soma += matriz[i][n - 1 - i];
    }
    return soma;
}


int ehSimetrica(int matriz[][1000], int l, int c) {
    if (l != c) {
        return 0;  
    }

    for (int i = 0; i < l; i++) {
        for (int j = 0; j < i; j++) {
            if (matriz[i][j] != matriz[j][i]) {
                return 0; 
            }
        }
    }
    return 1;  
}


void trocarLinhas(int matriz[][1000], int c, int i, int j) {
    for (int k = 0; k < c; k++) {
        int temp = matriz[i][k];
        matriz[i][k] = matriz[j][k];
        matriz[j][k] = temp;
    }
}


int somaDuasLinhas(int matriz[][1000], int c, int i, int j) {
    int soma = 0;
    for (int k = 0; k < c; k++) {
        soma += matriz[i][k] + matriz[j][k];
    }
    return soma;
}


int elementoDominante(int matriz[][1000], int l, int c, int i, int j) {
    int elemento = matriz[i][j];
    int vizinhos[8][2] = {
        {-1, -1}, {-1, 0}, {-1, 1},
        {0, -1},           {0, 1},
        {1, -1}, {1, 0}, {1, 1}
    };

    for (int k = 0; k < 8; k++) {
        int x = i + vizinhos[k][0];
        int y = j + vizinhos[k][1];

        if (x >= 0 && x < l && y >= 0 && y < c && matriz[x][y] >= elemento) {
            return 0;  
        }
    }
    return 1;  
}

int main() {
    int l, c;
    printf("Digite o número de linhas e colunas da matriz: ");
    scanf("%d %d", &l, &c);

    int matriz[1000][1000];

    printf("Digite os elementos da matriz:\n");
    for (int i = 0; i < l; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    int opcao;
    printf("Escolha uma opção:\n");
    printf("1. Calcular média da linha\n");
    printf("2. Calcular média da coluna\n");
    printf("3. Calcular soma diagonal principal (se matriz quadrada)\n");
    printf("4. Calcular soma diagonal secundária (se matriz quadrada)\n");
    printf("5. Verificar se a matriz é simétrica\n");
    printf("6. Trocar o conteúdo de duas linhas\n");
    printf("7. Calcular soma de duas linhas\n");
    printf("8. Verificar elemento dominante\n");
    scanf("%d", &opcao);

    if (opcao == 1) {
        int linha;
        printf("Digite o número da linha: ");
        scanf("%d", &linha);
        printf("A média da linha %d é: %lf\n", linha, mediaLinha(matriz, l, c, linha - 1));
    } else if (opcao == 2) {
        int coluna;
        printf("Digite o número da coluna: ");
        scanf("%d", &coluna);
        printf("A média da coluna %d é: %lf\n", coluna, mediaColuna(matriz, l, c, coluna - 1));
    } else if (opcao == 3) {
        if (l == c) {
            printf("A soma da diagonal principal é: %d\n", somaDiagonalPrincipal(matriz, l));
        } else {
            printf("A matriz não é quadrada.\n");
        }
    } else if (opcao == 4) {
        if (l == c) {
            printf("A soma da diagonal secundária é: %d\n", somaDiagonalSecundaria(matriz, l));
        } else {
            printf("A matriz não é quadrada.\n");
        }
    } else if (opcao == 5) {
        if (ehSimetrica(matriz, l, c)) {
            printf("A matriz é simétrica.\n");
        } else {
            printf("A matriz não é simétrica.\n");
        }
    } else if (opcao == 6) {
        int linha1, linha2;
        printf("Digite o número das duas linhas a serem trocadas: ");
        scanf("%d %d", &linha1, &linha2);
        trocarLinhas(matriz, c, linha1 - 1, linha2 - 1);
        printf("Linhas trocadas com sucesso!\n");
    } else if (opcao == 7) {
        int linha1, linha2;
        printf("Digite o número das duas linhas a serem somadas: ");
        scanf("%d %d", &linha1, &linha2);
        int soma = somaDuasLinhas(matriz, c, linha1 - 1, linha2 - 1);
        printf("A soma das linhas %d e %d é: %d\n", linha1, linha2, soma);
    } else if (opcao == 8) {
        int linha, coluna;
        printf("Digite a posição (linha e coluna) do elemento a ser verificado: ");
        scanf("%d %d", &linha, &coluna);
        if (elementoDominante(matriz, l, c, linha - 1, coluna - 1)) {
            printf("O elemento na posição %d, %d é dominante.\n", linha, coluna);
        } else {
            printf("O elemento na posição %d, %d não é dominante.\n", linha, coluna);
        }
    } else {
        printf("Opção inválida.\n");
    }

    return 0;
}
