#include <stdio.h>

int main() {
    int vetor[20];
    printf("Digite os 20 inteiros do vetor:\n");
    for (int i = 0; i < 20; i++) {
        scanf("%d", &vetor[i]);
    }
    for (int i = 0; i < 19; i++) {
        int menor = i;
        for (int j = i + 1; j < 20; j++) {
            if (vetor[j] < vetor[menor]) {
                menor = j;
            }
        }
        if (menor != i) {
            int temp = vetor[i];
            vetor[i] = vetor[menor];
            vetor[menor] = temp;
        }
    }
    printf("Vetor ordenado:\n");
    for (int i = 0; i < 20; i++) {
        printf("%d ", vetor[i]);
    }

    return 0;
}