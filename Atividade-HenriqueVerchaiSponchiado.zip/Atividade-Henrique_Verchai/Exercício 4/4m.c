#include <stdio.h>

int aloca_prova(char sala[100][100], int n, int m) {
  // Verifica se a matriz tem as dimensões esperadas
  if (n > 100 || m > 100) {
    return 0;
  }

  // Verifica se as carteiras das primeiras e últimas colunas estão vazias
  for (int i = 0; i < n; i++) {
    if (sala[i][0] != '0' || sala[i][m - 1] != '0') {
      return 0;
    }
  }

  // Verifica se as carteiras das primeiras e últimas fileiras estão vazias
  for (int i = 0; i < m; i++) {
    if (sala[0][i] != '0' || sala[n - 1][i] != '0') {
      return 0;
    }
  }

  // Verifica se as regras de vizinhança são satisfeitas
  for (int i = 1; i < n - 1; i++) {
    for (int j = 1; j < m - 1; j++) {
      int vizinhos_vazios = 0;
      for (int k = -1; k <= 1; k++) {
        for (int l = -1; l <= 1; l++) {
          if (sala[i + k][j + l] == '0') {
            vizinhos_vazios++;
          }
        }
      }

      if (vizinhos_vazios < 2) {
        // Se existem menos de dois vizinhos vazios, verifica se os vizinhos ocupados têm versões diferentes da prova
        int n_vizinhos_ocupados = 0;
        for (int k = -1; k <= 1; k++) {
          for (int l = -1; l <= 1; l++) {
            if (sala[i + k][j + l] != '0') {
              n_vizinhos_ocupados++;
              if (k == 0 && l == 0) {
                continue;
              }

              // Verifica se a versão da prova do aluno atual é diferente da versão da prova do vizinho
              if (sala[i][j] == sala[i + k][j + l]) {
                return 0;
              }
            }
          }
        }
      }
    }
  }

  return 1;
}

int main(){
char sala[4][4] = {
  "0000",
  "0ab0",
  "00c0",
  "0000",
};

int n = 4;
int m = 4;

int resultado = aloca_prova(sala, n, m);

if (resultado == 1) {
  printf("A alocação de provas é válida.\n");
} else {
  printf("A alocação de provas é inválida.\n");
}
}