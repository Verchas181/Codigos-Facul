#include <stdio.h>

int main() {
    int numeros[2];
    int temp;

    printf("Digite o primeiro número: ");
    scanf("%d", &numeros[0]);
    
    printf("Digite o segundo número: ");
    scanf("%d", &numeros[1]);


    if (numeros[0] > numeros[1]) {
        temp = numeros[0];
        numeros[0] = numeros[1];
        numeros[1] = temp;
    }

    printf("Os números em ordem crescente são: %d, %d\n", numeros[0], numeros[1]);

    return 0;
}
