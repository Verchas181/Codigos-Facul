#include <stdio.h>

// Função para verificar se um caractere é uma letra maiúscula
int ehMaiuscula(char ch) {
    return (ch >= 'A' && ch <= 'Z');
}

// Função para verificar se um caractere é uma letra minúscula
int ehMinuscula(char ch) {
    return (ch >= 'a' && ch <= 'z');
}

// Função para verificar se um caractere é um número
int ehNumero(char ch) {
    return (ch >= '0' && ch <= '9');
}

int main() {
    char nome[100]; // Supomos um nome de até 100 caracteres
    int i;

    printf("Digite um nome próprio: ");
    scanf("%s", nome);

    int erro = 0;

    for (i = 0; nome[i] != '\0'; i++) {
        if (!ehMaiuscula(nome[0])) {
            erro = 1;
            break;
        } else if (!(ehMaiuscula(nome[i]) || ehMinuscula(nome[i]))) {
            erro = i + 1;
            break;
        } else if (ehNumero(nome[i])) {
            erro = i + 1;
            break;
        }
    }

    if (erro == 0) {
        printf("Bem-vindo Sr. %s\n", nome);
    } else {
        printf("Erro de digitação na posição %d\n", erro);
    }

    return 0;
}
