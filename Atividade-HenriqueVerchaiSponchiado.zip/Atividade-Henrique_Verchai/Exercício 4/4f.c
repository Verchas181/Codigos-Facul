#include <stdio.h>
int vec[12];
int main(){
    for (int i =2;i<40;i++){
        if(i%2 == 0){
        vec[i-2]=i;
        }
    }
    return 0;
}