#include <stdio.h>
char vec[40];
int main(){
    printf("Digite um nome");
    scanf("%s",&vec);
    printf("\n %d",strlen(vec));
    return 0;
}