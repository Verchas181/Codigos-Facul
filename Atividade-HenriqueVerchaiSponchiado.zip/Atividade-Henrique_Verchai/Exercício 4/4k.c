#include <stdio.h>

int main() {
    int matriz[30][30], transposta[30][30];
    int linhas, colunas;

    printf("Digite o número de linhas (máximo 30): ");
    scanf("%d", &linhas);
    if (linhas > 30) {
        printf("O número de linhas excede o máximo permitido (30).\n");
        return 1;
    }

    printf("Digite o número de colunas (máximo 30): ");
    scanf("%d", &colunas);
    if (colunas > 30) {
        printf("O número de colunas excede o máximo permitido (30).\n");
        return 1;
    }
    printf("Digite os elementos da matriz:\n");
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            scanf("%d", &matriz[i][j]);
        }
    }

    for (int i = 0; i < colunas; i++) {
        for (int j = 0; j < linhas; j++) {
            transposta[i][j] = matriz[j][i];
        }
    }

    printf("Matriz transposta:\n");
    for (int i = 0; i < colunas; i++) {
        for (int j = 0; j < linhas; j++) {
            printf("%d ", transposta[i][j]);
        }
        printf("\n");
    }

    return 0;
}
