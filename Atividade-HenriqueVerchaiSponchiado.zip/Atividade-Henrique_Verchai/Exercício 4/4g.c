#include <stdio.h>
int vec[9];
int c=0;
int s=0;
int sum=0;
int main(){
    printf("Escreva 8 numeros");
    for(int i=0;i<8;i++){
    scanf("%d",&vec[i]);
    }
    for(int j =0;j<8;j++){
        print("%d",vec[j]);
        if (vec[j]>30){
            c+=1;
            s += vec[j];
        }
        sum += vec[j];
    }
    printf("%d,%d,%d",c,s,sum);
   
    
    return 0;
}