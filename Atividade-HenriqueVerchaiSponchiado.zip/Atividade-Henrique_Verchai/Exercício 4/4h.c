#include <stdio.h>
char vec1[50];
char vec2[50];
char vec3[50];
int c = 0;
int main(){
    print("Escreva três nomes:");
    scanf("%s",vec1);
    scanf("%s",vec2);
    scanf("%s",vec3);
    for (int i =0;i<50;i++){
        if(vec1[i] == 'A' || vec1[i] == 'E'){
            c++;
        }
        if(vec2[i] == 'A' || vec2[i] == 'E'){
            c++;
        }
        if(vec3[i] == 'A' || vec3[i] == 'E'){
            c++;
        }
    }
    printf("%d",c);
    return 0;

}