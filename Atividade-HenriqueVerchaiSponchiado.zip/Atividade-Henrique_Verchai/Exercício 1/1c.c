#include <stdio.h>

int main() {
    int vec[3];
    int a;
    
    for (int i = 0; i < 3; i++) {
        printf("Digite o %dº valor: ", i + 1);
        scanf("%d", &vec[i]);
    }
    printf("Valores na ordem de leitura: %d, %d, %d\n", vec[0], vec[1], vec[2]);

    for (int i = 0; i < 1; i++) {
        if (vec[i] < vec[i+1]){
        a = vec[i];
        vec[i] = vec[i+1];
        vec[i+1] = a;
    }
    }
    for (int i = 0; i < 1; i++) {
        if (vec[i] < vec[i+1]){
        a = vec[i];
        vec[i] = vec[i+1];
        vec[i+1] = a;
    }
    }
    printf("Valores em ordem decrescente: %d, %d, %d\n", vec[0], vec[1], vec[2]);

    return 0;
}
