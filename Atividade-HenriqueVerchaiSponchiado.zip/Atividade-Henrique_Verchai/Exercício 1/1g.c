#include <stdio.h>

int main() {
    char nome[60];
    char sex;
    int idade;

    printf("Digite o nome:");
    fgets(nome,59,stdin);

    printf("Digite o sexo (M para masculino, F para feminino): ");
    scanf(" %c", &sex);

    printf("Digite a idade: ");
    scanf("%d", &idade);

    if ((sex == 'F' || sex == 'f')&& idade < 25) {
        printf(" %s \nACEITA",nome);
    }
    else{
        printf("NÃO ACEITA");
    }

    return 0;
}