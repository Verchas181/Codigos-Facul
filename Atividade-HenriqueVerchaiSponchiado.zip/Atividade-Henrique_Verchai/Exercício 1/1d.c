#include <stdio.h>

int main() {
    double a, b, x;

    // Solicita ao usuário que insira os valores de 'a' e 'b'
    printf("Digite o valor de 'a': ");
    scanf("%lf", &a);
    printf("Digite o valor de 'b': ");
    scanf("%lf", &b);

    // Verifica os casos
    if (a == 0) {
        if (b == 0) {
            printf("Infinitas soluções.\n");
        } else {
            printf("Sem solução.\n");
        }
    } else {
        x = -(b / a);
        printf("A solução é x = %.2lf\n", x);
    }

    return 0;
}




