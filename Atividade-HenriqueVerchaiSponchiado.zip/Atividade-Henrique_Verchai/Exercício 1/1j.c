 #include <stdio.h>
float a;
float b;
int horas = 0;
int minutos = 0;
float segundos = 0;
int main() {
    printf("Escreva quantos minutos");
    scanf("%f",&a);
    b = a*60;

    while (b > 3600){
        b -= 3600;
        horas += 1;
    }
    while (b <= 3600 && b > 60){
        b -=60;
        minutos += 1;
    }
    segundos = b;

    printf("As horas exatas são %d horas, %d minutos e %f segundos",horas,minutos,segundos);
    
    
    return 0;
}