// Primeira Parte 
if(x>0 && x<13{
    printf("Intervalo Correto\n");
}


// Segunda Parte
if(D == 'F' || D == 'M'){
    printf("D representa um genero\n");
}


// Terceira Parte
if((x % 2) == 0){
    printf("x é par\n");
}
else {
    printf("x é ímpar");
}


// Quarta Parte
if (ano < 0 || m < 1 || m > 12 || (m == 2 && dia > 28) || ((m == 4 || m == 6 || m == 9 || m == 11) && dia > 30) || ((m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12) && dia > 31)) {
    printf("Data inválida\n");
}


