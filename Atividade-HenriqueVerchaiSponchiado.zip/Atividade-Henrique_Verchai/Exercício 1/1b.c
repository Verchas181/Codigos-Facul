#include <stdio.h>

float preco1;
int n;



int main (){
    printf("Digite o preço de um produto e o numero de parcelas:");
    scanf("%f",preco1);
    scanf("%d",n);
    if (n == 3) {
        preco1 = preco1*1.1; 
        printf("O produto tem preço final de %f.\n", preco1);
    }
    if (n == 5) {
        preco1 = preco1*1.2;
        printf("O produto tem preço final de %f.\n", preco1);
    }

    
    return 0;
}