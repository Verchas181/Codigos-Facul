#include <stdio.h>
int a;
int main() {
    printf("Digite um número inteiro");
    scanf("%d",a);
    if (a > 0){
        if (a % 2 == 0){
            printf("%d é par.",a);
        }
    else{
        printf("%d é ímpar.",a);
        }
    }
    return 0;
}