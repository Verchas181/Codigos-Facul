 #include <stdio.h>
int a;
int b;
int i = 0;
int c;
int main() {
    printf("Escreva dois numeros");
    scanf("%d",&a);
    scanf("%d",&b);
    while (c < b){
        c = a*i;
        i++;
    }
    printf("%d",i);
    return 0;
}