#include <stdio.h>

int main() {
    char sex;
    double altura, peso;

   
    printf("Digite o sexo (M para masculino, F para feminino): ");
    scanf(" %c", &sex);

    printf("Digite a altura em metros: ");
    scanf("%lf", &altura);

    if (sex == 'M' || sex == 'm') {
        peso = (72.7 * altura) - 58;
    } 
    if (sex == 'F' || sex == 'f') {
        peso = (62.1 * altura) - 44.7;
    }
    
    printf("O peso ideal é: %.2lf kg\n", peso);

    return 0;
}
