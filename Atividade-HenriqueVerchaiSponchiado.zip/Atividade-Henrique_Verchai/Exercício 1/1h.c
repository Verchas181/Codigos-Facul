#include <stdio.h>
int a;
int main() {
    printf("Escreva um numero");
    scanf("%d",&a);
    if (a>20){
        printf("%d",a/2);
    }
    return 0;
}