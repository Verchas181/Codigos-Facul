#include <stdio.h>
char nome1[50];
char nome2[50];
float preco1;
float preco2;


int main (){
    printf("Digite o nome e preço de um produto:");
    scanf("%s",&nome1);
    scanf("%s",&nome2);
    printf("Digite nome e preço de outro produto:");
    scanf("%f",&preco1);
    scanf("%f",&preco2);

    if (preco1 > 20) {
        printf("O produto %s tem preço superior a 20 reais.\n", nome1);
    }
    if (preco2 > 20) {
        printf("O produto %s tem preço superior a 20 reais.\n", nome2);
    }

    
    if (preco1 < 10) {
        printf("O produto %s tem preço inferior a 10 reais. Preço: %.2f reais.\n", nome1, preco1);
    }
    if (preco2 < 10) {
        printf("O produto %s tem preço inferior a 10 reais. Preço: %.2f reais.\n", nome2, preco2);
    }

    return 0;
}