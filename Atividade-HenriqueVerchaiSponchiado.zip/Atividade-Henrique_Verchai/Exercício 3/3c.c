#include <stdio.h>


void Vogal(char caractere) {
    
    caractere = tolower(caractere);
    
    
    if (caractere == 'a' || caractere == 'e' || caractere == 'i' || caractere == 'o' || caractere == 'u') {
        print("É vogal"); 
    } else {
        printf("Não é vogal");
    }
}

int main() {
    char letra;

    printf("Digite um caractere: ");
    scanf(" %c", &letra);

    Vogal(letra);
    return 0;
}
