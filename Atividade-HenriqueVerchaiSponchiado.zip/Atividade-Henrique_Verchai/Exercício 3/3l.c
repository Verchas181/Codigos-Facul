#include <stdio.h>

int pot(float x,int y){
    float z=1;
    if (y = 0){
        return 1;
    }
    else{
    return x*pot(x,y-1);
    }
}
int main(){
    printf("Escreva um número e sua potência:");
    float a;
    int b;
    scanf("%f",&a);
    scanf("%d",&b);
    float z = pot(a,b);
    printf("%f",z);
    return 0;
}