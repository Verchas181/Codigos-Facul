void prod(int a, int b, int c){
    printf("%d",(a+b)*c);

}
int main(){
    int x,y,z;
    scanf("%d",&x);
    scanf("%d",&y);
    scanf("%d",&z);
    prod(x,y,z);
    return 0;
}