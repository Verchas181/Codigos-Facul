#include <stdio.h>

int cTriangulos(int n) {
    if (n == 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return n + 2 * cTriangulos(n - 1) - cTriangulos(n - 2);
    }
}

int main() {
    int n;
    printf("Digite a altura da grade (n): ");
    scanf("%d", &n);

    int resultado = cTriangulos(n);

    printf("O número de triângulos de pé em uma grade de altura %d é: %d\n", n, resultado);

    return 0;
}
