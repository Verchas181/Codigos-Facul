#include <stdio.h>

// Função recursiva para encontrar o elemento mínimo em um vetor
int Emax(int vec[], int tamanho) {
    if (tamanho == 1) {
        return vec[0];
    } else {
        // Encontre o mínimo nos primeiros (tamanho - 1) elementos
        int maxRestante = Emax(vec, tamanho - 1);

        if (vec[tamanho - 1] > maxRestante) {
            return vec[tamanho - 1];
        } else {
            return maxRestante;
        }
    }
}

int main() {
    int v[] = {5, 3, 8, 1, 12, 4, 7};
    int size = sizeof(v) / sizeof(v[0]);

    int min= Emax(v, size);

    printf("O elemento mínimo no vetor é: %d\n", min);

    return 0;
}
