#include <stdio.h>

// Função para preencher o vetor com números lidos da entrada
void preencherVetor(int vetor[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        printf("Digite o número para a posição %d: ", i);
        scanf("%d", &vetor[i]);
    }
}

// Função para imprimir o vetor
void imprimirVetor(int vetor[], int tamanho) {
    printf("Vetor: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

// Função para imprimir o quadrado de cada número do vetor
void imprimirQuadrado(int vetor[], int tamanho) {
    printf("Quadrados: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i] * vetor[i]);
    }
    printf("\n");
}

// Função para imprimir o primeiro e o último número do vetor
void imprimirPrimeiroEUltimo(int vetor[], int tamanho) {
    if (tamanho > 0) {
        printf("Primeiro número: %d\n", vetor[0]);
    }
    if (tamanho > 0) {
        printf("Último número: %d\n", vetor[tamanho - 1]);
    }
}
int c;

int main() {
    int vetor[5];
    printf("Escolha entre as seguintes funções: \n [1]preencherVetor \n [2]imprimirVetor \n [3]imprimirQuadrado \n [4]imprimirPrimeiroEUltimo");

    scanf("%d",c);
    if (c == 1){
    preencherVetor(vetor, 5);
    }
    if(c == 2){
    imprimirVetor(vetor, 5);
    }
    if(c == 3){
    imprimirQuadrado(vetor, 5);
    }
    if(c == 4){
    imprimirPrimeiroEUltimo(vetor, 5);
    }
    
    return 0;
}
