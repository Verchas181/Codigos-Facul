void funk(float a, float b, float c ){
    int sum = a*a + b + c;
    printf("%d",sum);
}
int main(){
    int x,y,z;
    scanf("%f",&x);
    scanf("%f",&y);
    scanf("%f",&z);
    funk(x,y,z);
    return 0;
}