void max(int vec[],int size){
    int a = -100000000;
    for (int i = 0;i<size;i++){
        if (a < vec[i]){
            a = vec[i];
        }
    }
    printf("%d",a);
}

int main(){
    int vec[50];
    int a = srtlen(vec);
    max(vec,a);
    return 0;
}