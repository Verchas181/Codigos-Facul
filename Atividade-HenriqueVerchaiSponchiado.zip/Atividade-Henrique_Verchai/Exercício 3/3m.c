#include <stdio.h>

int Palin(int num) {
    int original = num;
    int reverso = 0;

    while (num > 0) {
        int digito = num % 10;
        reverso = reverso * 10 + digito;
        num /= 10;
    }

    return original == reverso;
}

int main() {
    int numero;

    printf("Digite um número inteiro: ");
    scanf("%d", &numero);

    if (Palin(numero)) {
        printf("%d é um número palíndromo.\n", numero);
    } else {
        printf("%d não é um número palíndromo.\n", numero);
    }

    return 0;
}
