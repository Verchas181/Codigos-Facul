#include <stdio.h>


void Vogal(char caractere) {
    
    caractere = tolower(caractere);
    
    
    if (caractere == 'a' || caractere == 'e' || caractere == 'i' || caractere == 'o' || caractere == 'u') {
        print("É vogal"); 
    } else {
        printf("Não é vogal");
    }
}

int main() {
    char letra[50];

    printf("Digite um caractere: ");
    for (int i = 0; i<49;i++){
    scanf(" %s", &letra[i]);
    Vogal(letra);
    }
    
    return 0;
}