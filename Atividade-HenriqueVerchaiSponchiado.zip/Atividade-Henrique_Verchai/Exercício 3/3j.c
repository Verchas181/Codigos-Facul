#include <stdio.h>

// Função que verifica se o caractere é um número
int numero(char ca) {
    return (ca >= '0' && ca <= '9');
}

// Função que verifica se o caractere é letra
int letra(char c) {
    return ((c >= 'A' && c <= 'Z') || (c>= 'a' && c <='z') );
}

int main() {
    char caractere;

    printf("Digite um caractere: ");
    scanf(" %c", &caractere);

    if (numero(caractere)) {
        printf("É um número (dígito).\n");
    } else {
        printf("Não é um número (dígito).\n");
    }

    if (letra(caractere)) {
        printf("É uma letra maiúscula.\n");
    } else {
        printf("Não é uma letra maiúscula.\n");
    }

    return 0;
}
