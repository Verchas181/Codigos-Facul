#include <stdio.h>
int produto(int a,int b){
    int c = 0;
    for (int i = 0;i<b;i++){
        c += a;
    }
    return c;
}

int main(){
    int x,z;
    printf("Escreva dois números para saber o seu produto:");
    scanf("%d",&x);
    scanf("%d",&z);
    printf("O produto é %d",produto(x,z));
    return 0;



}