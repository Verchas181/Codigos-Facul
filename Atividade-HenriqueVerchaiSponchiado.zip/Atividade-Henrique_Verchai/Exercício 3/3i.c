void funk(char v[],int N){
    for (int i = 0;i<N;i++){
        printf("%s",v);
    }
    int b = strlen(v);
    printf("%c",v[b-1]);

}

int main(){
    char vec[40];
    int a;
    printf("Escreva uma frase e um numero inteiro:");
    scanf("%s",&vec);
    scanf("%d",a);

    funk(vec,a);
    return 0;
}