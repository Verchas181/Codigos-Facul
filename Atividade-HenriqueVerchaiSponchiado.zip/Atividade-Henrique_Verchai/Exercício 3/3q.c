#include <stdio.h>

int lg(int n) {
  if (n <= 1) {
    return 0;
  } else {
    return 1 + lg(n / 2);
  }
}
int main() {
  printf("Escreva um numero inteiro para saber seu piso em ln");
  int z;
  scanf("%d",&z);
  int lg_n = lg(z);
  printf("O piso do logaritmo de %d na base 2 é %d.\n", z, lg_n);
  return 0;
}